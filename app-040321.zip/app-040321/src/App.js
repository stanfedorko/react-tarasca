import React from 'react';
import './App.css';
import { Router, Switch, Route } from 'react-router-dom';
// import { Router } from 'react-router-dom';
import Home from './components/Home';
import Blog from './components/Blog';
// import Search from './components/Search';
import History from './components/History';
// import Details from './components/Details';
import Header from './components/Header';
import Footer from './components/Footer';

function App() {
  return (
    <>
      <Router history={History}>
        <div className='main'>
          <Header />
          {/* <Home /> */}
          <Switch>
            <Route path='/' component={Home} exact />
            <Route path='/blog' component={Blog} />
            {/* <Route path='/details/:language' component={Details} /> */}
          </Switch>
          <Footer />
        </div>
      </Router>
    </>
  );
}

export default App;
